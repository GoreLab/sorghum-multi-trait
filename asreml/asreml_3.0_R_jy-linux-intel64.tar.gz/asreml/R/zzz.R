.onLoad <- function(libname, pkgname) {
  loadNamespace("utils")
  ##  License (asreml.lic not exported in namespace)
  asreml:::asreml.lic()
}
.onUnload <- function(libpath) {
  ## Relinquish a license
  library.dynam.unload("asreml",libpath)
}
